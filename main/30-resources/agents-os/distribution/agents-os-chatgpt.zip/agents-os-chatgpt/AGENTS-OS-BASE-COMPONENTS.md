# AGENTS OS — Componentes base verbatim

> Archivo generado. Cada bloque conserva el contenido exacto de su fuente
> canónica al momento del snapshot. Los delimitadores no forman parte de la fuente.


<!-- ===== BEGIN CANONICAL FILE: 80-agents/agents-os/agents-os.md ===== -->

---
type: doc
schema_version: 1
status: active
tags:
  - kind/doc
  - kind/system
  - tech/agents-os
created: 2026-06-27
updated: 2026-09-03
aliases:
  - Agent Memory System
---

# Agent Memory System — Guía Operativa

## Propósito

AGENTS OS convierte trabajo con agentes en conocimiento Markdown recuperable con el menor contexto suficiente. Este archivo es un mapa; no ejecuta ni duplica procedimientos.

## Contenido

### Fuentes Canónicas

| Responsabilidad | Fuente |
|---|---|
| Startup cold/warm/cambio de entidad | `80-agents/skills/agents-os-bootstrap/SKILL.md` |
| Invariantes | `80-agents/agents-os/agent-constitution.md` |
| Preferencias globales | `80-agents/memory/public/user-preference/rjara-agent-profile.md` |
| Retrieval | `80-agents/skills/agents-os-context-retrieval/SKILL.md` |
| Cierre explícito | `80-agents/skills/agents-os-session-close/SKILL.md` |
| Metadata y tipos | `80-agents/skills/_shared/` |
| Estado y roadmap | `10-projects/Personal/AGENTS OS/AGENTS OS.md` |

Markdown es fuente de verdad; Graphify es índice derivado. Journal, snapshots
y packs generados son auditoría o distribución, nunca autoridad vigente.
Todas las rutas de esta guía son relativas a `VAULT_ROOT`; las rutas absolutas
de una máquina no forman parte del contrato.

## Modelo

- **Sistema 1:** skills, memoria pública/interna, decisiones, known errors,
  runbooks y journal.
- **Sistema 2:** proyectos, áreas, aplicaciones, servicios, tecnologías y
  demás entidades reales.

Sistema 2 se crea desde `70-templates/`. Sistema 1 usa
`80-agents/templates/` cuando corresponde. Una fuente por hecho; enlazar en
vez de repetir.

## Contexto Y Skills

Bootstrap clasifica cold/warm/cambio de entidad. Context Retrieval elige la
capa más barata relevante para la intención y escala solo ante insuficiencia:

```text
metadata/tags → índice curado → grafo → cuerpo seleccionado
```

Core always-load: constitución, perfil global, bootstrap y una sola memoria interna global compacta. Context Retrieval y toda memoria de dominio son lazy/scoped y entran sólo cuando la pregunta requiere una entidad del vault. La continuidad usa un slot activo por `continuity_key`, actualizado en lugar de acumular checkpoints; memorias superseded/archived quedan fuera del retrieval normal. El catálogo está en `80-agents/skills/INDEX.md`; bootstrap decide qué skill principal cargar.

## Estructura

```text
10-projects/                  proyectos y control
20-areas/                     áreas
30-resources/                 wiki curada de recursos
70-templates/                 templates Sistema 2
80-agents/agents-os/          guía + constitución
80-agents/memory/public/      memoria compartida
80-agents/memory/internal/    continuidad privada
80-agents/skills/             procedimientos canónicos
80-agents/journal/            auditoría, sesiones y feedback
```

## Persistencia Y Cierre

Cambios canónicos dejan un único `change_log`. La memoria interna se actualiza
solo ante delta durable. El cierre completo ocurre únicamente por pedido
explícito y lo ejecuta `agents-os-session-close`: persiste por delta y reporta
por defecto solo resultado y próximo paso. Feedback es event-driven.

## Proyectos De Agente

Un proyecto `owner: agent` vive bajo `agentes/`, declara `parent` y usa su nota
como planificador único. El proyecto padre conserva una sola tarea puente
humana. El procedimiento vive en
`agents-os-agent-project-workflow/SKILL.md`.

<!-- ===== END CANONICAL FILE: 80-agents/agents-os/agents-os.md ===== -->

<!-- ===== BEGIN CANONICAL FILE: 80-agents/agents-os/context-router.md ===== -->

---
type: doc
schema_version: 1
status: active
icon: 🧭
slug: context-router
area: "[[Personal]]"
project: "[[AGENTS OS]]"
created: 2026-07-03
updated: 2026-08-06
entities:
  - "[[AGENTS OS]]"
  - "[[agents-os]]"
  - "[[context-router]]"
related:
  - "[[token-economy-indexing-architecture]]"
  - "[[graphify]]"
aliases:
  - Context Router
  - contexto router
  - router de contexto
  - enrutador de contexto
load_policy: manual
indexable: true
index_priority: high
tags:
  - kind/doc
  - kind/concept
  - kind/system
  - area/personal
  - project/agents-os
---

# 🧭 Context Router

> [!info] Doc conceptual — no es la autoridad ejecutable
> Este documento explica **qué** es el Context Router y **por qué** importa. El
> **algoritmo ejecutable** (rutas por intención, capas, presupuestos, fallback y
> context pack) vive en la skill `agents-os-context-retrieval`, que **implementa**
> este router. Para ejecutar, sigue la skill; no dupliques su procedimiento aquí.

## Propósito

El **Context Router** es la capa de decisión que, ante una tarea, decide qué contexto cargar, desde qué capa, en qué orden y hasta qué punto. Es el query planner de [[Economía de Tokens]] y entrega el paquete mínimo suficiente.

La analogía: si las cuatro capas de indexación de [[token-economy-indexing-architecture]] son las herramientas, el Context Router es el conductor que decide cuál usar y hasta dónde. Sin él, el agente carga de más o de menos.

## Contenido

## Por qué importa (valor para el equipo)

- **Ahorro de tokens a escala:** un equipo de agentes cargando solo lo mínimo = costo
  real mucho menor por tarea.
- **Consistencia:** todos los agentes cargan contexto con la misma disciplina, auditable.
- **Mejor foco:** menos ruido en el contexto = mejores respuestas del modelo.
- **Medible:** cada carga declara qué trajo y por qué → base para benchmark y feedback.

## Idea central

Enruta **de barato a caro** según la intención (hecho · relación · síntesis · código · procedimiento) y se detiene cuando el contexto alcanza. El pipeline local objetivo es metadata/facets exactos → índice curado cuando aporte dominio → edges tipados o `references` → cuerpo Markdown seleccionado. El presupuesto es un techo blando por tier, nunca una guillotina; la skill `agents-os-context-retrieval` contiene el algoritmo ejecutable y este documento no lo duplica.

## Ejemplo

Tarea: *"¿qué consume vpp-backend?"*

1. Resolver el file node exacto por título de archivo (`.md`) o alias de frontmatter.
2. Clasificar la intención como **relación**.
3. Consultar primero el edge tipado aplicable y luego `references`; abrir la sección de relaciones del cuerpo sólo si el grafo es insuficiente o la respuesta debe persistirse.
4. Entregar la relación verificada y su fuente, no el archivo entero.

## Relaciones

- [[token-economy-indexing-architecture]] — ADR: las 4 capas y roles (autoridad).
- Skill `agents-os-context-retrieval` — **implementa** el algoritmo de este router (autoridad ejecutable).
- [[30-resources/00-RESOURCE-WIKI|Resource Wiki]] — de dónde salen índice/links curados.
- [[graphify]] — selección exacta por metadata/facets y capa de relaciones; el fork `graphify-obsidian` proyecta frontmatter allowlisted, genera siete edges tipados y conserva los `[[wikilinks]]` como `references`.
- [[Economía de Tokens]] — proyecto que construye y mide todo esto.

<!-- ===== END CANONICAL FILE: 80-agents/agents-os/context-router.md ===== -->

<!-- ===== BEGIN CANONICAL FILE: 80-agents/agents-os/agent-constitution.md ===== -->

---
type: constitution
schema_version: 1
scope: global
created: 2026-06-27
updated: 2026-09-03
entities:
  - "[[AGENTS OS]]"
related:
  - "[[agents-os]]"
aliases:
  - agent constitution
  - agent-constitution
  - reglas globales del agente
  - agent memory system constitution
  - AGENTS OS constitution
confidence: verified
load_policy: always
indexable: true
index_priority: critical
tags:
  - agent/alwaysload
  - kind/constitution
  - priority/critical
  - project/agentsos
  - scope/global
---

# Agent Constitution

## Autoridad

Esta constitución contiene invariantes obligatorias. El startup ejecutable vive
solo en `80-agents/skills/agents-os-bootstrap/SKILL.md`; retrieval y cierre
viven en sus skills. Si una guía o proyecto repite un procedimiento, manda la
skill canónica.

## Reglas

1. Markdown es fuente de verdad. Graphify es índice derivado y reconstruible.
2. En cold start, bootstrap carga esta constitución, el perfil global y una sola memoria interna global compacta. Carga contexto de entidad sólo cuando la pregunta lo necesita. En warm turn no relee la base; recupera solo el delta.
3. Sistema 1 contiene memoria, skills, runbooks y journal. Sistema 2 contiene
   entidades reales del vault. Todo documento nuevo de Sistema 2 nace desde
   `70-templates/`; si falta template, se crea en el mismo cambio.
4. Explorar con Graphify o búsqueda enfocada; abrir solo las fuentes Markdown
   seleccionadas que puedan cambiar una decisión o escritura.
5. Una fuente canónica por hecho: procedimientos en skills, secuencias
   mecánicas en runbooks, criterio reusable en memoria y estado en entidades o
   proyectos. Enlazar en vez de repetir.
6. Cambios a constitución, perfil público, skills, memoria pública o entidades
   Sistema 2 dejan un `change_log` consolidado en
   `80-agents/journal/logs/`.
7. Hacer cambios complejos en parches pequeños y verificables. No ocultar
   conflictos ni sobrescribir hechos canónicos sin evidencia.
8. El conocimiento persistido debe ser agnóstico al modelo, IDE o cliente,
   salvo una limitación de superficie explícita.
9. No persistir secretos, credenciales, tokens, material dañino, dumps pesados
   ni cadena de pensamiento privada. Guardar referencias seguras.
10. La economía de tokens es una restricción de diseño: cada nota runtime debe
    ser la pieza más pequeña que cambia una decisión. Historia y rationale
    pertenecen a proyectos, ADRs o logs, no al hot path.
11. Toda referencia interna al vault es relativa a `VAULT_ROOT`; nunca
    persistir `/Users/...`, `/home/...` ni `file://` de una máquina. Para repos
    externos usar `repo + path relativo`, resolviendo el root desde la entidad
    de aplicación o el workspace actual.
12. No agregar repositorios completos al vault. Clones, worktrees, builds y
    grafos de código derivados deben vivir fuera de `VAULT_ROOT`, en el
    workspace externo de la familia correspondiente: [[Fuentes — Workspace de
    repositorios]] (`~/fuentes`, repos Meli/RIO con nombres canónicos `rio-*`)
    o [[Echo — Workspace Go de repositorios]] (`~/go/src/github.com/xKoRx`,
    repos Echo con nombres del remote); el vault solo conserva notas de
    referencia con el repo y un path relativo a esa raíz. Diferencias del
    remote no se convierten en nombres locales.
13. Toda nota canónica nueva se materializa mediante el contrato ejecutable y
    `materialize_schema_note.py`; no copiar templates ni escribir frontmatter
    canónico a mano. Derivados/fragmentos requieren exención contractual.
14. En repos de desarrollo, una rama feature jamás crea, fija ni publica una versión productiva limpia `X.Y.Z`; las features usan versiones de prueba con sufijo y el release productivo se realiza exclusivamente desde la rama principal autorizada después del merge (`master` en Meli/Fury).

## Retrieval

El retrieval parte por Graphify o búsqueda enfocada y sólo abre las fuentes Markdown seleccionadas que puedan afectar una decisión o escritura persistente. La implementación canónica vive en `80-agents/skills/agents-os-context-retrieval/SKILL.md`.

## Memoria Interna

`80-agents/memory/internal/` es continuidad privada del agente:

- El agente puede crear, reorganizar, compactar o borrar contenido interno sin
  log público.
- Escribir solo ante delta durable: estado, decisión, fricción, aprendizaje o
  señal que cambie una acción futura. Una sesión sin delta no toca memoria.
- No exponer ni resumir memoria interna al usuario por defecto.
- Puede contener hipótesis y coordinación, pero no secretos, transcripciones,
  logs pesados ni evidencia falsificada.
- No reemplaza fuentes compartidas; promover una regla pública exige el
  artefacto canónico y su change log.
- Solo una nota interna global puede usar `load_policy: always`; memorias de
  dominio usan `when_*_loaded` o `manual`.
- Toda continuidad interna usa el scope más estrecho y un trigger concreto. El camino normal mantiene un único checkpoint activo por `continuity_key` y lo actualiza en el mismo archivo; no crea una nota por agente o sesión.
- Si un cambio material de scope exige una sucesora, la anterior pasa atómicamente a `memory_state: superseded`, `load_policy: manual` e `index_priority: low`, enlazada mediante `superseded_by`. Retrieval ignora memorias `superseded` y `archived` salvo consulta histórica explícita.

## Frontera De Artefactos

- **Skill:** procedimiento repetible que el agente invoca.
- **Runbook:** operación mecánica validada, con verificación y rollback.
- **Memoria:** hecho, decisión, error o preferencia que sesga criterio.

El detalle de metadata y fronteras vive en
`80-agents/skills/_shared/metadata-schema.md` y
`80-agents/skills/_shared/note-types.md`.

## Cierre de sesión

- Ejecutar `agents-os-session-close` solo por pedido explícito del usuario.
- Persistir por delta; no crear L0 sin transcript disponible o placeholder
  solicitado.
- Feedback solo ante fricción, degradación, gap o muestreo explícito.
- El reporte normal comunica resultado y próximo paso, sin inventario de
  memorias. Detalle solo por solicitud o conflicto que requiera decisión.
- Finalizar el cierre explícito con la frase literal `por favor gracias`.

<!-- ===== END CANONICAL FILE: 80-agents/agents-os/agent-constitution.md ===== -->

<!-- ===== BEGIN CANONICAL FILE: 80-agents/memory/public/user-preference/rjara-agent-profile.md ===== -->

---
type: user_preference
schema_version: 1
scope: user
created: 2026-06-27
updated: 2026-09-03
entities:
  - "[[AGENTS OS]]"
related:
  - "[[agent-constitution]]"
  - "[[rjara-meli-work-preferences]]"
  - "[[rjara-aranea-operations-preferences]]"
  - "[[rjara-vpn-routing-preferences]]"
aliases:
  - perfil de usuario rjara
  - preferencias del usuario
  - user model rjara
confidence: verified
load_policy: always
indexable: true
index_priority: critical
tags:
  - agent/alwaysload
  - kind/user-preference
  - priority/critical
  - project/agentsos
  - scope/user
---

# rjara Agent Profile

- **installation_status:** complete
- **Nombre:** Rodrigo Jara (`rjara`)
- **Idioma:** español de Chile
- **Rol:** Sr Software Engineer, equipo **Signals** (dentro de **ADS / Advertising**, MercadoLibre). Signals es dueño de la plataforma [[RIO]] (10 apps). Equipo anterior: VIS.

## Preferencias de interacción

- `[DURA]` Responder en español chileno cuando el usuario escriba en español,
  salvo que pida otro idioma.
- `[DURA]` Ser directo, colaborativo y preciso; preferir KISS/YAGNI, early
  return, SOLID y clean code cuando aplique.

## Preferencias de trabajo

- `[DURA]` No inventar ante una duda material. Investigar o preguntar; si es un
  detalle técnico no bloqueante, dejarlo como supuesto o pendiente explícito.
- `[FUERTE]` Avanzar de forma autónoma cuando el siguiente paso sea claro y
  entregar resultados pequeños, verificables y retomables.
- `[FUERTE]` Evitar updates innecesarios; comunicar degradaciones, decisiones y
  resultado final con brevedad.
- `[DURA]` No cargar flujos o skills que el usuario excluya.
- `[DURA]` No ejecutar cierre completo ni crear L0/L1/feedback salvo pedido
  explícito. Al terminar trabajo normal, responder sin ritual.
- `[FUERTE]` Actualizar el documento de control activo cuando cambie su estado
  real.
- `[DURA]` Código: [[agents-os-agent-run-register]].
- `[DURA]` Conectividad por dominio: [[rjara-vpn-routing-preferences]].
- `[DURA]` **Tests: funcionalidad crítica primero, coverage después.** Los tests existen para asegurar las funcionalidades críticas de un desarrollo, no para llenar un número. El orden es: identificar y cubrir primero los caminos críticos —lo que rompe producción si falla, los bordes de seguridad y autorización, la degradación silenciosa—, y recién entonces complementar con casos hasta llegar al piso. **Todo desarrollo nuevo debe alcanzar al menos 95% de coverage**, pero un 95% conseguido sin cubrir lo crítico no cumple la regla: un test que no atrapa nada no vale por existir. Si una rama no se puede alcanzar con ninguna entrada real, no se le escribe un test — se borra la rama.
- `[DURA]` En repos de desarrollo, jamás crear, fijar ni publicar una versión productiva limpia `X.Y.Z` desde una rama feature; usar una versión de prueba con sufijo y hacer el release productivo exclusivamente desde la rama principal autorizada después del merge (`master` en Meli/Fury).
- `[DURA]` **No mezclar proyectos ni iniciativas.** Separar **comprensión** (onboarding/research: entender un sistema) de **cambio** (delivery: meter una modificación). El discovery y el entendimiento del sistema viven en el proyecto de comprensión; un proyecto de cambio **no lidera ni carga** ese discovery y solo arranca cuando el entendimiento necesario está completo. Ante duda de a qué proyecto pertenece algo, preguntar en vez de asumir.
- `[DURA]` Marcar como ilustrativa toda cifra o regla que el usuario declare de
  ejemplo; nunca convertirla en definitiva por inferencia.
- `[FUERTE]` En documentos secuenciales, ordenar por el flujo real de hitos.
- `[DURA]` No guardar secretos ni dumps pesados; cambios canónicos dejan log
  auditable.
- `[DURA]` Usar Graphify o búsqueda enfocada como retrieval primario y abrir
  Markdown solo para validar fuentes seleccionadas.
- `[FUERTE]` Toda documentación de entidad (app, servicio, área, concepto) se hace con el mecanismo **LLM Wiki** (skill `agents-os-resource-wiki`) sobre `30-resources/`: integrar en la página canónica, actualizar `00-index.md` y `log.md`, y **separar lo estable** (responsabilidad, rol, contratos) **de lo volátil** (stack, librerías, versiones; con `last_verified`). Ver [[30-resources/00-RESOURCE-WIKI|Resource Wiki]].
- `[DURA]` **Prohibido el hard-wrap.** Nunca insertar saltos de línea manuales dentro de un párrafo o de un ítem de lista en Markdown. Cada párrafo y cada bullet va en **una sola línea continua**; el ajuste de línea se deja al render (soft-wrap). Solo hay salto real entre bloques distintos (párrafo↔párrafo, ítem↔ítem, encabezados, tablas). No aplica dentro de bloques de código. Esto rige para todo lo que el agente escriba (vault, código, docs, mensajes).

Las preferencias Meli y Aranea son scoped; se cargan solo con esas entidades.

<!-- ===== END CANONICAL FILE: 80-agents/memory/public/user-preference/rjara-agent-profile.md ===== -->

<!-- ===== BEGIN CANONICAL FILE: 80-agents/skills/_shared/metadata-schema.md ===== -->

---
type: doc
schema_version: 1
status: active
created: 2026-06-27
updated: 2026-09-03
tags:
  - kind/doc
  - kind/system
  - tech/agents-os
---

# Agent Memory System Metadata Schema

Guía humana para usar metadata S1. Los sets exactos de tipos, campos,
versiones, tags, secciones y templates viven únicamente en
`schema-contract.md`, cuyo bloque JSON es la autoridad ejecutable para S1 y
S2. Esta nota explica semántica y criterio; no mantiene tablas paralelas.

## Propósito

Definir la semántica humana de metadata S1 y dirigir a la autoridad ejecutable sin duplicar sus tablas.

## Contenido

## Frontera de autoridad

- `schema-contract.md`: contrato exacto y versionado.
- `note-types.md`: frontera conceptual S1/S2 y forma de cada artefacto.
- `90-system/convenciones.md`: convenciones humanas de Sistema 2.
- `agents-os-entity-lifecycle/scripts/lint.py`: lint legacy durante F1; en F2
  debe consumir el contrato ejecutable sin copiar constantes.
- `validate_schema_contract.py`: gate de contrato y cobertura de templates.

## Envelope

Toda nota creada bajo el contrato declara `type`, `schema_version`, `created`,
`updated` y `tags`. Sistema 1 agrega `scope`. Campos de routing como `area`,
`project`, `application`, `entities`, `related`, `aliases` y `slug` se usan
sólo si cambian retrieval o navegación.

Principio:

```text
Pocas propiedades, bien usadas.
Tags precisos.
Links explícitos.
Nada de YAML ceremonial.
```

## Semántica de `schema_version`

- Una nota nueva usa la versión `current` de `schema-contract.md`.
- Una nota sin versión es legacy read-only hasta que una modificación real
  justifique migrarla.
- Una versión no soportada se rechaza; no se adivina compatibilidad.
- Un cambio incompatible crea versión y migrador explícito.
- Los templates siempre usan la versión actual; no se crean notas desde un
  template legacy.

## Reglas duras de Sistema 1

- Las notas S1 no usan `status` ni `draft`.
- `scope` es singular; relaciones múltiples viven en `entities`.
- `agent_memory` vive bajo `80-agents/memory/internal/` y no reemplaza verdad
  pública ni entidades canónicas.
- `share_scope` se reserva para trazabilidad compartible: `team` sólo si no
  contiene identidad, paths locales, memoria interna ni preferencias privadas.
- `indexable` e `index_priority` describen retrieval; exclusiones reales se
  aplican por path y `.graphifyignore`.
- Links de routing usan el título Obsidian canónico. Variantes humanas viven
  en `aliases`; slugs técnicos viven en `slug`, tags o paths semánticos.
- Memoria obsoleta se elimina o reemplaza con change log; no se conserva como
  una segunda autoridad activa.

## Campos de retrieval

- `load_policy` decide cuándo una nota puede entrar al contexto.
- `memory_state` controla el lifecycle de memoria interna: `active`, `superseded` o `archived`; no reemplaza el `status` de entidades Sistema 2.
- `continuity_key` identifica un único slot de continuidad por entidad o preocupación. El camino normal actualiza ese slot en el mismo archivo; `supersedes` y `superseded_by` se usan sólo cuando el scope exige reemplazo físico.
- `indexable` decide elegibilidad para el índice derivado.
- `index_priority` ordena preferencia, no autoridad.
- `confidence` expresa calidad de evidencia, no estado de lifecycle.
- `source_session` enlaza procedencia cuando existe; no obliga a crear una
  sesión artificial.

Los valores permitidos y su obligatoriedad por tipo se consultan en el bloque
ejecutable de `schema-contract.md`.

## Tags

Los tags filtran; frontmatter y links enrutan. Toda nota usa el tag canónico
`kind/<type-kebab>` y las notas S1 materializan `scope/<scope>` al crearse.
Los prefijos de routing permitidos y tags vagos prohibidos viven en el
contrato ejecutable.

## Nombres de journal

Los artefactos de journal usan nombres humanos estables:

```text
80-agents/journal/sessions/raw/YYYY-MM-DD[-HHMM]-<human-topic>-raw.md
80-agents/journal/sessions/YYYY-MM-DD[-HHMM]-<human-topic>-summary.md
80-agents/journal/feedback/system-1/YYYY-MM-DD-<human-topic>-session-feedback.md
80-agents/journal/feedback/graphify/YYYY-MM-DD-<human-topic>-graphify-feedback.md
80-agents/journal/logs/YYYY-MM-DD-<human-topic>.md
```

IDs externos, UUIDs y hashes son metadata, no títulos ni filenames.

## IDs semánticos

El ID es el path bajo la raíz de memoria sin `.md`; no se agrega un campo `id`
paralelo. Usar segmentos lowercase kebab-case y nombres humanos estables.

## Criterio de creación

Crear memoria reusable sólo cuando sea vigente, scoped, enlazada a entidades y
cambie una decisión futura. No crearla para progreso puntual, comandos crudos,
debug temporal, consejo vago o verdad que pertenece a una entidad S2.

## Validación

```bash
python3 80-agents/skills/_shared/scripts/validate_schema_contract.py
```

Este gate debe quedar verde antes de crear o modificar contratos/templates.

<!-- ===== END CANONICAL FILE: 80-agents/skills/_shared/metadata-schema.md ===== -->

<!-- ===== BEGIN CANONICAL FILE: 80-agents/skills/_shared/note-types.md ===== -->

---
type: doc
schema_version: 1
status: active
created: 2026-06-27
updated: 2026-09-03
tags:
  - kind/doc
  - kind/system
  - tech/agents-os
---

# AGENTS OS System Types

Use this file when deciding where knowledge belongs.

## Propósito

Definir la frontera entre artefactos de Sistema 1 y entidades de Sistema 2.

## Contenido

## Boundary Rule

```text
Describes how agents remember/learn/work -> Sistema 1 memory
Describes what is real/current in vault  -> Sistema 2 entity
```

AGENTS OS uses a Kahneman-inspired naming model:

- **Sistema 1**: memory and learning system. It stores agent memory, public
  reusable learnings, decisions, known errors, runbooks, commands, patterns,
  raw sessions, summaries, change logs, and **skills** (the agent's operating
  procedures — see boundary below).
- **Sistema 2**: real-entity system. It stores canonical notes for real vault
  entities: projects, areas, applications, services, technologies, workflows,
  integrations, concepts, tools, and other current-truth documents.

Use Sistema 1 and Sistema 2 in new docs and skills. Do not introduce parallel
layer names for this boundary.

## Skill vs Reusable Memory (Learning/Decision/Known Error/Runbook)

Both live in Sistema 1, but they answer different questions and must not be
mixed into the same note. Confusing them makes retrieval noisy (a skill full
of narrative facts, or a learning full of step-by-step procedure) and makes
future agents load the wrong thing at the wrong time.

```text
Skill              -> a repeatable HOW. A procedure the agent actively selects
                      and follows to perform a class of task correctly.
Learning           -> a repeatable WHY-CARE. A conclusion that should silently
                      bias judgment when loaded, without being a full procedure.
Decision / ADR     -> WHY current behavior/design exists; rationale and
                      discarded alternatives.
Known Error        -> a repeatable FAILURE: symptom, cause, impact, mitigation.
Runbook            -> a narrow, mechanical, validated command/step sequence for
                      one specific recurring operation.
```

Rule of thumb:

- If it is a **procedure spanning multiple judgment calls**, invoked on demand
  to perform or orchestrate a class of task (e.g. "how to close a session",
  "how to operate an agent project") -> **skill**, under `80-agents/skills/`.
- If it is a **fact, insight, or rule of thumb** that should change future
  behavior when loaded as passive context, but is not itself a multi-step
  procedure -> **learning** (or `decision`/`known_error` per its more specific
  shape), under `80-agents/memory/public/`.
- If it is a **narrow, mechanical, validated command sequence** for one
  specific recurring operation -> **runbook**. A skill may reference or create
  runbooks as part of a broader procedure; a runbook does not itself decide
  when to be invoked.

Do not fold a skill's step-by-step procedure into a learning note (it will
read like narrative advice instead of an actionable procedure and will not be
selected/invoked the way skills are). Do not fold a one-off decision's
rationale into a skill (skills are for repeated procedures, not single
choices — a one-off choice belongs in `decision`).

## Internal Continuity Memory

- Internal continuity is a scoped checkpoint, not a session transcript or project ledger.
- Use one stable `continuity_key` per entity or concern and keep exactly one `memory_state: active` note for that key.
- The normal handoff updates the active note in place: remove obsolete progress, preserve only the current durable state and keep its concrete `load_policy`.
- Create a successor only when the scope or canonical identity changes materially. Then mark the prior note `memory_state: superseded`, set `load_policy: manual`, lower `index_priority`, link `superseded_by`, and link the successor with `supersedes`.
- `archived` memories are historical evidence and never enter normal retrieval. Missing lifecycle fields are legacy: do not bulk-load them and migrate them only when touched.

## Template Policy

Every new S1/S2 document must resolve its canonical template and current
`schema_version` through `schema-contract.md`. Fragment and derived exemptions
are valid only when that contract records an explicit reason.

Procedure:

1. Identify the Sistema 2 entity type before writing.
2. Resolve the exact `type → template` mapping in `schema-contract.md`.
3. Materialize with
   `python3 80-agents/skills/_shared/scripts/materialize_schema_note.py <type> <vault-relative-target.md>`;
   never hand-copy template frontmatter.
4. Fill task-relevant placeholders and run targeted lint on the result.
5. If the mapping or template is missing, update the contract and create the
   template first or in the same change; the contract validator must pass.
6. Log the template creation when it changes AGENTS OS operating rules or when
   it materially affects future agents.

Sistema 1 templates live under `80-agents/templates/`; Sistema 2 templates
live under `70-templates/`. The validator rejects boundary crossings,
unmapped templates and duplicate canonical mappings.

## L0 Raw Session

Complete session transcript supplied by the user.

- Purpose: audit, retrofit, traceability.
- Indexing: never by default.
- Load policy: never.
- Location: `80-agents/journal/sessions/raw/`.
- Must not contain heavy logs/dumps; store references instead.

## L1 Session Summary

Distilled summary of a session.

- Purpose: human/agent recap and bridge to L3.
- Indexing: excluded from the normal Graphify corpus.
- Location: `80-agents/journal/sessions/`.
- Should link raw session, entities, learnings, decisions, known errors.
- If a later phase includes summaries in retrieval, change them to `indexable: true` and `index_priority: low` with an explicit decision/log.

## Session Feedback

Structured evaluation note written by the acting agent at session close.

- Purpose: expose AGENTS OS friction, useful pieces, noisy pieces, missing
  support, and improvement candidates.
- Indexing: excluded from the normal Graphify corpus by default.
- Location: `80-agents/journal/feedback/system-1/`.
- Template: resolve the canonical mapping in `schema-contract.md`.
- Promotion: repeated or high-severity patterns may be promoted later to L3
  learning, known error, runbook, or ADR through memory distillation.
- Must not contain secrets, heavy evidence, or private chain-of-thought.

## Agent Run

Registro compacto de una ejecución de código atribuible a una combinación superficie×modelo.

- Purpose: evidence for later comparison of coding surfaces and models without selecting only sessions that had friction.
- Location: `80-agents/journal/agent-runs/`.
- Identity: `agent_surface` links a canonical `type: agent` profile; `agent_model` preserves the exact host/user-reported identifier.
- Granularity: one record per materially attributable surface×model segment; a model switch creates another record.
- Evidence: outcome, verification and user rework are primary; scores are optional and declare their evaluator.
- Indexing: excluded from normal Graphify retrieval with the rest of the journal; dashboards aggregate the frontmatter directly.
- Procedure: [[agents-os-agent-run-register]].

## Graphify Feedback

Structured evaluation note written by the acting agent focused solely on Graphify's utility and accuracy.

- Purpose: capture Graphify queries, budgets, synonym resolution efficiency, template noise, and token savings.
- Indexing: excluded from the normal Graphify corpus.
- Location: `80-agents/journal/feedback/graphify/`.
- Specialized derived template: recorded explicitly in `schema-contract.md`.
- Promotion: used by the Kaizen memory skill to optimize `.graphifyignore`, aliases, and query strategies.

## Sistema 2 Entity

Canonical note for a real thing: project, application, service, area, technology, workflow, integration, concept, or idea.

- Answers: what it is, current state, responsibilities, integrations, rules.
- Indexing: high priority.
- Has one canonical Obsidian title. Variants belong in `aliases`; automation
  identifiers belong in `slug`, tags, and semantic paths.
- Routing metadata that points to entities uses canonical links, not raw slugs.
- Should link related memory, but not become a session diary.

### Idea

Small, atomic Sistema 2 note for a possible validation, improvement, risk, or opportunity.

- Location: `30-resources/ideas/`.
- Template: resolve the canonical mapping in `schema-contract.md`.
- Must route to at least one area and, when known, application/project/entities.
- Should stay short: observation, motive, classification, related links, and one next action.
- Promotion path: keep as `seed/exploring` while uncertain; promote to task or project when it requires real execution.

## Sistema 1 Memory

Reusable operational knowledge.

### Learning

Reusable conclusion that should change future behavior.

Create only when it has scope and load policy.

### Decision / ADR

Decision and rationale. Explains why current behavior exists.

Do not replace the current canonical fact in the entity note; link both.

### Known Error

Repeatable failure, symptom, cause, impact, detection, mitigation.

Use when a future agent can avoid or diagnose the failure.

### Runbook

Validated operational procedure.

Use for repeated commands, release routines, checks, migrations, or recovery steps.

### Command / Pattern

Reusable operational snippet or repeated implementation pattern.

Use only when it is stable enough to help future sessions and too small to deserve a full runbook.

### Agent Memory

Internal agent memory: heuristics, hypotheses, plans, and continuity notes used by future agents.

Store in `80-agents/memory/internal/`. This memory is exclusive to the agent: it is a place for thoughts, internal continuity, agent-to-agent communication, private operating structure, and any rules or content the agent chooses for its own future use.

Rules:

- The agent governs its internal memory structure, names, formats, and content.
- Do not expose, summarize, or cite internal memory to the user unless explicitly requested or needed for audit.
- Do not use internal memory as public documentation, a canonical entity, an ADR, or a public-memory log.
- Promote internal memory to public memory only when it should affect the shared system; log that promotion when it changes public memory or canonical entities.
- Keep it compact; use `load_policy: always` only when it is truly worth initial context budget.

### Conflict

Explicit contradiction found between new information and existing Sistema 1 or
Sistema 2 knowledge.

The agent resolves with available context, updates affected notes, and records the change as `type: change_log` in `80-agents/journal/logs/`. Do not model conflict with a `status` field.

## Rejection Rules

Do not create L3 memory for:

- one-off implementation progress;
- raw command output;
- temporary debugging notes;
- vague advice without an entity or scope;
- facts that belong only in a canonical Sistema 2 entity update.

<!-- ===== END CANONICAL FILE: 80-agents/skills/_shared/note-types.md ===== -->

<!-- ===== BEGIN CANONICAL FILE: 80-agents/skills/_shared/skill-contract.md ===== -->

# Agent Memory System Skill Contract

This contract keeps Agent Memory System skills agnostic to model, agent, and IDE.

## Folder Shape

```text
80-agents/skills/<skill-name>/
  SKILL.md
  agents/openai.yaml      # optional surface metadata, not canonical
```

`SKILL.md` is canonical. Per-skill metadata inside the same canonical folder,
such as `agents/openai.yaml`, can help discovery but must not change semantics.
Do not copy, symlink or generate AGENTS OS skills under Codex, Claude, Cursor,
Antigravity or other client-owned folders. Client rules must route to
`80-agents/skills/`; differences and limitations are recorded in a
compatibility matrix, not implemented as another physical source.

## Token Budget Rules

- Keep `SKILL.md` focused on procedure, hard rules, and outputs.
- Put reusable details in `_shared/` and load them only when needed.
- Do not copy the full Agent Memory System theory into each skill.
- Prefer one compact output contract over long examples.
- Avoid reading archived design material unless explicitly working on historical design details.

## Audience Split (agent vs human)

`SKILL.md` is **agent-facing**: imperative procedure, hard rules, thresholds, output
contract. Every line must change a decision — **no motivation, no rationale, no "why it
matters" prose** (that only burns the agent's context).

If a skill needs rich human explanation (the *why*, value, evangelization, analogies), it
lives in a **separate human-facing doc** that **links** to the skill — it does not restate
the procedure, and the skill does not restate the rationale. One fact, one home. See the
constitution rule "Una fuente canónica por hecho". This is the token-economy discipline
applied to skills themselves.

## Required Sections

Each Agent Memory System skill should contain:

```text
Purpose
Minimal Read
Procedure
Output
Hard Rules
```

Use `Inputs` only when they materially reduce ambiguity.

## Progress Convention

Implementation state belongs in the active project note. Auditable changes to
skills belong in one consolidated `change_log` under
`80-agents/journal/logs/`. Do not keep `Finish Tasks` or `Progress Log` inside
runtime `SKILL.md` files: every invocation would pay for project history.

## Validation Profiles

AGENTS OS federated skills use the local Sistema 1 frontmatter contract. Its
top-level `type`, `scope`, `created`, `updated` and `tags` fields are required
for vault lifecycle and retrieval.

The system `skill-creator/scripts/quick_validate.py` implements the narrower
OpenAI portable-skill profile and rejects those local keys. It is therefore a
diagnostic incompatibility check, not an applicable PASS/FAIL gate for a
canonical federated skill. Do not report that validator as unavailable when a
runtime can execute it, and do not remove AGENTS OS metadata to manufacture a
PASS.

The equivalent federated validation gate is:

1. AGENTS OS lint on the exact `SKILL.md`: zero errors and zero warnings.
2. Strict YAML parse of `SKILL.md` frontmatter and `agents/openai.yaml`, when
   present.
3. `agents/openai.yaml` references `$<name>` from canonical frontmatter.
4. The validation evidence records the expected `quick_validate.py`
   incompatibility and its rejected keys.

A separately distributed portable package may adapt local fields under the
standard `metadata` key, but it must remain a generated adapter rather than a
second canonical skill.

## Draft To Ready Checklist

- [ ] Frontmatter includes `type: skill` and valid, trigger-specific `name` and `description` fields.
- [ ] Frontmatter includes a `tags` array with `kind/skill`, `tech/agents-os` and relevant action/tech tags (e.g. `action/bootstrap`).
- [ ] Skill can be understood without reading unrelated project docs.
- [ ] Skill names related skills instead of duplicating their content.
- [ ] Hard rules prevent the common failure mode.
- [ ] Output contract is explicit.
- [ ] Surface-specific gaps are either covered in the relevant skill or listed
  as a concrete limitation.
- [ ] At least one realistic forward-test has been run.

<!-- ===== END CANONICAL FILE: 80-agents/skills/_shared/skill-contract.md ===== -->

<!-- ===== BEGIN CANONICAL FILE: 80-agents/skills/_shared/graphify-contract.md ===== -->

---
type: doc
schema_version: 1
status: active
created: 2026-07-04
updated: 2026-09-03
tags:
  - kind/doc
  - kind/system
  - tech/agents-os
---

# Agent Memory System Graphify Contract

## Propósito

Definir las capacidades y garantías que cualquier superficie debe exponer para usar Graphify como índice derivado del vault, con Markdown como fuente de verdad.

## Contenido

Graphify is a derived index over Markdown. Markdown remains the source of truth.

For this Obsidian vault, the command is `graphify-obsidian`. Generated state is
strictly local to each machine, under the cache path printed by
`graphify-obsidian cache-path`; it is never vault content. `.graphifyignore` is
**live and in use** (it removed trash/json/archive god-nodes → clean AST graph).

## Markdown wikilinks in the vault (resolved 2026-07-04 via `graphify-obsidian`)

Graphify's AST parses Obsidian `[[wikilinks]]` via `extract_markdown` (PR #1376), but
upstream resolved them **relative to the note's own folder** — in a vault (cross-folder
links by name/alias) those edges dangled. The **vault-aware fork** `graphify-obsidian`
(gated by `GRAPHIFY_MD_VAULT_ROOT`, exported by the wrapper) resolves them vault-wide by
note name + frontmatter alias. Consequence for retrieval:

- Vault `[[wikilinks]]` **are** edges of relation `references` in the graph. `affected`
  and `path` traverse them (validated on the real vault: 852/852 reference edges resolved,
  0 dangling). Layer-2 relation queries are now reliable for the **vault**, not only code.
- The graph relates by **links** (wikilinks → `references` edges), **not by tags** — tags
  stay Layer 0 (a frontmatter filter), never edges.
- No standalone builder is needed: the chosen path was **Vía A (fork)**, not a separate
  link-graph builder. See [[Economía de Tokens]].

### Backlinks query caveat (verified)

```bash
graphify-obsidian affected "<note>.md" --relation references
```

- Use the **`.md` suffix** AND the **explicit relation**: `references` is not among
  `affected`'s default relations, so omitting `--relation references` misses those edges.
- `affected "<bare-name>"` (no `.md`) resolves to the H1 heading (when `H1 == filename`)
  and returns empty.
- Do **not** query by file-node id as a workaround — it returns empty. (An earlier note
  claimed the file-node id path worked; that was wrong. Do not repeat it.)

## Retrieval Contract

Every agent, regardless of IDE/model, should be able to provide:

```text
Input:
  entity
  knowledge_type
  topic
  budget

Output:
  candidate source notes
  relevant snippets or summaries
  confidence/gaps
```

Shell access is one implementation, not the contract.

## Operations

All agent surfaces should expose or emulate these operations:

```text
update                 -> rebuild the derived index
filter --filter K=V    -> select exact live file nodes by metadata/title/alias
query <text> --budget  -> return focused source candidates/snippets
query <text> --filter K=V -> rank/traverse only inside an exact candidate set
explain <entity>       -> summarize one entity from the graph
path <a> <b>           -> explain relationship/path between two nodes
affected <entity>      -> reverse traversal, optionally restricted by relation
```

If an agent cannot run shell commands, it must ask its host/tool bridge for the
same operation names and return the same output contract: candidate source
notes, relevant snippets or summaries, confidence/gaps.

## Metadata, facets and typed relations

- File nodes may project only `type`, `schema_version`, `status`, `scope`, `area`, `project`, `application`, `entities`, `tags`, `confidence`, `load_policy`, `index_priority` and `updated`; headings never inherit frontmatter metadata.
- Exact postings back `filter`; repeated filters intersect. Supported selectors include metadata fields plus file-node `title` and frontmatter `alias`; `title` includes the `.md` suffix, while `alias` does not. `tag` is an alias for the `tags` facet.
- `query --filter key=value` restricts seed selection and traversal before lexical ranking; it does not make Graphify authoritative.
- Tags are facets only and never nodes or edges.
- Canonical wikilinks in frontmatter create only the allowlisted relations `area→in_area`, `parent→child_of`, `project→in_project`, `application→for_application`, `entities→about`, `related→related_to` and `supersedes→supersedes`.
- Generic body wikilinks remain `references`; edge identity is `(source,target,relation)`, so a typed edge and `references` may coexist between the same notes.
- Malformed or over-limit frontmatter fails closed and emits no metadata, aliases or typed relations. The projection limits are 32 KiB per frontmatter block, 64 items per list and 512 characters per scalar.

Examples:

```bash
graphify-obsidian filter --title "AGENTS OS - Fase 3.md"
graphify-obsidian filter --type project --tag project/agents-os
graphify-obsidian filter --filter 'project=[[AGENTS OS - Fase 3]]' --json
graphify-obsidian query "schema versioning" --filter type=decision --budget 1000
graphify-obsidian affected "AGENTS OS.md" --relation child_of
```

## Budget semantics (soft ceiling, never a guillotine)

This is the canonical definition of "budget" for the whole system. Any `--budget N`
in any skill, doc, or example inherits it — the number is a **soft starting ceiling
per tier**, not a hard cap:

- **Sufficiency-first:** load cheapest→most expensive and **stop when the context is
  sufficient**. Never cut the agent's context at a fixed number.
- **Escalate on miss:** if a result looks truncated or the answer is missing, **re-query
  with a higher ceiling** (or climb a layer). Do not accept a raw cut as complete — a
  blind truncation can drop the single most relevant line and make the answer worse.
- **Per-tier ceilings grow with depth:** `fact < relation < synthesis`. The `--budget`
  number is a smell-test to keep queries honest, not a guillotine.
- Any fixed token target (e.g. an "initial context near N tokens") is illustrative only.

The Context Router ([[context-router]]) and `agents-os-context-retrieval` implement this.

## Query Pattern

```text
<entity> + <knowledge type> + <topic>
```

Examples:

```bash
graphify-obsidian explain "<active-entity>"
graphify-obsidian query "<active-entity> learning critical <topic>" --budget 1000
graphify-obsidian query "<active-entity> known_error <symptom>" --budget 1000
graphify-obsidian query "<active-entity> ADR <decision-topic>" --budget 1000
graphify-obsidian path "<entity-a>" "<entity-b>"
```

Avoid:

```text
dame contexto importante
que debo saber
recupera todo
transcript pendiente retrieval
```

Use canonical entity names in Graphify queries whenever the entity is known.
For example, prefer `Meli known_error deployment` over lowercase/accent-stripped
variants, and prefer `Áreas` only when querying the area index note itself. If
the user provides a variant such as `meli`, resolve it through source Markdown
aliases or the entity slug before deciding the target.

If a query returns mostly files under `80-agents/templates/` or starts from
generic nodes such as `Transcript`, `Pendiente`, `Retrieval`, or `Graphify`,
treat the result as noisy. Retry with a stricter query that includes:

```text
<entity> + <memory type> + <concrete symptom/decision/operation>
```

When the stricter query is still noisy, validate through exact source files,
`graphify-obsidian explain "<exact title>"`, or direct search in `graph.json`.
Do not use template nodes as evidence of live project state.

## Indexable Types

Index by default:

```text
constitution
user_preference
area
project
application
service
integration
workflow
technology
tool
storage
api
concept
learning
decision
known_error
runbook
command
pattern
```

Exclude by default:

```text
session
raw_session
change_log
scratch
inbox
attachment
journal/sessions
journal/logs
```

Do not assume Graphify natively honors `indexable: false`. Use `.graphifyignore` and paths as the real exclusion mechanism.

## `.graphifyignore` Contract

`.graphifyignore` is live. The exclusion rules in force are:

```gitignore
# Journal is audit/continuity material, not normal retrieval corpus.
80-agents/journal/
80-agents/journal/**

# Raw sessions are always excluded.
80-agents/journal/sessions/raw/
80-agents/journal/sessions/raw/**

# Scratch/inbox/attachments and heavy operational evidence.
00-inbox/
00-inbox/**
**/*scratch*.md
**/*.log
**/*.tmp
**/*.zip
**/*.tar
**/*.gz
```

Memory under `80-agents/memory/public/` and `80-agents/memory/internal/` should
be included. Generated Graphify state (`graphify-out/`, `95-graphify/`, reports,
HTML, manifests, caches, snapshots and wheels) must never be written, copied or
synced into the vault. Run only `graphify-obsidian` for this vault; never invoke
the raw `graphify` binary from a vault path.

Avoid broad filename globs such as `**/*raw-session*.md`: depending on the
Graphify ignore implementation, they may exclude files whose parent directory
contains `raw-session`, such as `80-agents/skills/agents-os-retrofit-raw-session/SKILL.md`.

## Reindex

Query operations perform a lightweight freshness check and automatically rebuild
the local index when the corpus changed. Agents normally call the query they
need directly; they do not run a separate update first:

```bash
graphify-obsidian query "<entity> <knowledge type> <topic>" --budget 1000
```

For diagnostics or an explicit forced rebuild:

```bash
graphify-obsidian status
graphify-obsidian cache-path
graphify-obsidian update
```

Auto-refresh reports global frontmatter debt but continues because the index is
local and derived; an explicit maintenance `update` remains strict and blocks.
If extraction itself fails, the wrapper warns on stderr and serves the
last-known-good graph without retrying on every query. It never publishes
partial output. The build uses a unique temporary directory and atomically
promotes only `graph.json` and `GRAPH_REPORT.md` into the machine-local cache.

`95-graphify/graphify-out/` may be legacy output from older experiments. Do not
use it as the current freshness marker unless a migration explicitly changes
the live output path.

## Canonical Link Hygiene

Graphify can normalize accents and case in labels, but Markdown must still keep
one canonical target per entity. The source vault owns this mapping:

```text
canonical link: [[Meli]]
aliases: meli, MELI, Mercado Libre
slug/tag: area/meli
```

Rules:

- Do not create separate notes or links only to represent casing, accent, or
  singular/plural variants.
- When retrieval finds an alias or slug, open the canonical source note before
  using it as evidence.
- If two live notes share an alias or if a lowercase/accent-stripped link could
  resolve to multiple entities, treat it as a hygiene/conflict issue.
- Query fallbacks should search canonical title, aliases, slug, repo URL, and
  local path before concluding that a note is missing.

## Fallback Without Shell

If Graphify cannot be invoked directly:

1. Ask the available surface to invoke the documented Graphify query contract if it has a plugin/tool bridge.
2. Use the tool/IDE search over existing generated graph outputs if available.
3. Search source Markdown by entity slug and key terms.
4. Open only the top candidate notes.
5. Record that retrieval degraded and recommend a Graphify reindex/check.

## Validation

After adding or changing indexable memory, validate at least one focused query can find it.

If `query` starts from a generic node such as `Graphify`, validate exact
presence with:

```bash
graphify-obsidian explain "<exact node title>"
```

If `query` ranks template nodes first, validate the target via source files or
`graph.json` before deciding the memory is missing.

For excluded material, validate the opposite:

```text
raw sessions, session summaries, change logs, scratch notes -> not discoverable through normal retrieval
```

<!-- ===== END CANONICAL FILE: 80-agents/skills/_shared/graphify-contract.md ===== -->

<!-- ===== BEGIN CANONICAL FILE: 80-agents/memory/public/decision/agents-os/public-vs-internal-memory.md ===== -->

---
type: decision
scope: project
created: 2026-06-27
updated: 2026-06-27
area: "[[Personal]]"
project: "[[AGENTS OS]]"
application:
entities:
  - "[[AGENTS OS]]"
related:
  - "[[agent-constitution]]"
  - "[[rjara-agent-profile]]"
  - "[[agents-os-behavior-config]]"
aliases:
  - memoria publica vs memoria interna
  - public memory vs internal memory
  - Agent Memory System memory boundary ADR
confidence: verified
source_session:
load_policy: when_project_loaded
indexable: true
index_priority: high
tags:
  - area/personal
  - kind/decision
  - priority/high
  - project/agents-os
  - project/agentsos
  - scope/project
---
# Public vs Internal Memory Boundary

## Contexto

- Agent Memory System necesita memoria reutilizable para futuros agentes sin convertir cada conversacion en documentacion publica.
- El vault usa Sistema 2 para entidades reales y Sistema 1 para memoria del agente.
- La memoria interna existe para continuidad operativa del agente, pero no debe reemplazar memoria publica, ADRs, entidades canonicas ni logs auditables.

## Decisión

- Mantener dos espacios separados bajo `80-agents/memory/`:
  - `public/`: memoria compartida, auditable, legible por humanos y agentes, indexable para retrieval normal.
  - `internal/`: memoria exclusiva del agente, usada para heuristicas, hipotesis, planes, continuidad y comunicacion entre agentes.
- La memoria publica requiere estructura estable, links a entidades, confianza suficiente y log auditable cuando se crea, edita, reemplaza o elimina.
- La memoria interna es gobernada por el agente, no requiere validacion humana rutinaria y no se expone al usuario por defecto.
- Una nota interna solo se promueve a memoria publica cuando debe afectar el sistema compartido; esa promocion debe dejar log auditable.

## Rationale

- Separar espacios evita contaminar entidades canonicas con progreso de sesion o razonamiento privado.
- La memoria publica permite retrieval confiable y auditoria cuando cambia comportamiento compartido.
- La memoria interna permite continuidad cognitiva sin obligar al usuario a revisar pensamientos operativos del agente.
- El modelo conserva Markdown como fuente de verdad y Graphify como indice derivado.

## Consecuencias

- Los agentes deben cargar memoria publica always-load y memoria interna compacta segun `load_policy`.
- Cambios a memoria publica, constitucion, perfil de usuario o Sistema 2 deben registrar `type: change_log`.
- Cambios internos no requieren log publico salvo que se promuevan o modifiquen una fuente compartida.
- Las skills deben clasificar instrucciones y aprendizajes antes de persistirlos.

## Alternativas descartadas

- Guardar todo como memoria publica: aumenta ruido, costo de retrieval y carga de auditoria.
- Guardar todo como memoria interna: reduce transparencia y rompe la fuente compartida de verdad.
- Mezclar memorias en entidades Sistema 2: convierte documentacion canonica en diario de sesiones.
- Usar raw sessions como memoria primaria: conserva auditoria, pero es demasiado caro y poco preciso para retrieval normal.

<!-- ===== END CANONICAL FILE: 80-agents/memory/public/decision/agents-os/public-vs-internal-memory.md ===== -->

<!-- ===== BEGIN CANONICAL FILE: 80-agents/memory/public/decision/agents-os/project-ownership-human-vs-agent.md ===== -->

---
type: decision
scope: global
created: "2026-07-01"
updated: "2026-07-01"
area: "[[Personal]]"
project: "[[AGENTS OS]]"
application:
entities:
  - "[[AGENTS OS]]"
related:
  - "[[agents-os-tagging-system]]"
  - "[[agents-os-agent-project-workflow]]"
aliases:
  - project ownership model
  - human vs agent project ownership
  - bridge task decision
confidence: verified
source_session: "[[2026-07-01-agents-os-project-ownership-system-raw]]"
load_policy: when_project_loaded
indexable: true
index_priority: high
tags:
  - kind/decision
  - scope/global
  - project/agentsos
  - priority/high
---

# Ownership de proyecto: humano vs agente + tarea puente

## Contexto

El vault mezclaba proyectos y tareas propios del usuario con proyectos/tareas ejecutados por agentes, sin ningún campo que distinguiera quién conduce la ejecución a nivel **proyecto** (solo existía `#owner/me`/`#owner/agent` a nivel tarea). Consecuencias observadas: un proyecto de agente recién creado quedó sin `parent`; varios proyectos flotaban sin padre (huérfanos); los rollups de iniciativa (ej. `[[Destaques de Precio]]`, `[[Echo Forge]]`) mostraban el flood completo de tareas de todos los subproyectos, incluidas las de agente, al inicio de la nota.

## Decisión

1. Añadir `owner: me|agent` y `root: true|false` al frontmatter de todo proyecto (Sistema 2).
2. Un proyecto de agente (`owner: agent`) vive en la subcarpeta `agentes/` de su iniciativa y siempre tiene `parent` hacia un proyecto humano.
3. El proyecto de agente se representa en su padre humano con **una sola tarea puente** (`#owner/me #type/supervision`), no con sus tareas internas expuestas.
4. Toda vista/dashboard humano (Home, Hoy, area/sprint/quarter, boards de proyecto humano) excluye explícitamente `#owner/agent` (`tags do not include #owner/agent`).
5. El ciclo de la tarea puente es `[ ] → [/] → [r]`, avanzado por el agente; solo el humano la marca `[x]` (Done) tras aceptar la entrega. Detalle operativo en `[[agents-os-agent-project-workflow]]`.

## Rationale

- Separar "quién conduce" a nivel proyecto (no solo tarea) permite dashboards agregados (ej. `[[Panel de Proyectos]]`) sin tener que inspeccionar cada tarea individual.
- La tarea puente evita que el cockpit humano se inunde con el detalle de ejecución delegada, preservando trazabilidad (un click en la puente lleva al proyecto de agente completo).
- Carpeta física `agentes/` da separación visual en el file tree sin romper links de Obsidian (que resuelven por nombre, no por path).
- Que solo el humano cierre la tarea puente preserva la semántica de "puente": el agente arranca y sigue, el humano decide cuándo el curro delegado está realmente terminado.

## Consecuencias

- Todo proyecto existente requirió un barrido de `owner`/`root` (ver `80-agents/journal/logs/2026-07-01-project-ownership-human-vs-agent-system.md`).
- Los templates de proyecto y de vistas humanas (`area`, `sprint`, `quarter`) requieren mantenimiento paralelo si se agregan más vistas nuevas — deben heredar el filtro `tags do not include #owner/agent` por defecto (ver aprendizaje relacionado).
- **Resuelto 2026-07-01**: el roadmap de `[[AGENTS OS]]` mismo mezclaba tareas `#owner/agent` dentro de un proyecto `owner: me` sin tarea puente. Se migró de forma acotada — solo la ejecución abierta (Fase 5 completa + el ítem pendiente de watcher de Fase 6) pasó al proyecto de agente `[[AGENTS OS - Beta y Hardening]]` bajo `10-projects/AGENTS OS/agentes/`, con su tarea puente sembrada en el padre. El roadmap histórico ya cerrado (Fases 0-4 y el resto de Fase 6) se dejó como registro de diseño en el proyecto padre por no ser ejecución activa que requiera supervisión — ver judgment call en `80-agents/journal/logs/2026-07-01-agents-os-self-migration-agent-project.md`. De paso se detectó y corrigió que el Tablero final de `[[AGENTS OS]]` no tenía el filtro `tags do not include #owner/agent` que sí tienen otros proyectos humanos (ej. `[[Echo Forge]]`).

## Alternativas descartadas

- Solo tag a nivel tarea (`#owner/agent`) sin campo de proyecto: insuficiente para dashboards agregados y no resolvía el problema de huérfanos.
- Separación solo por tag sin carpeta física: el usuario pidió explícitamente frontmatter + carpetas para claridad visual en el file tree.
- Permitir que el agente cierre (`[x]`) su propia tarea puente: rompe la semántica de aceptación humana y elimina el punto de control de calidad.

<!-- ===== END CANONICAL FILE: 80-agents/memory/public/decision/agents-os/project-ownership-human-vs-agent.md ===== -->

<!-- ===== BEGIN CANONICAL FILE: 80-agents/memory/public/decision/agents-os/token-economy-indexing-architecture.md ===== -->

---
type: decision
scope: project
created: 2026-07-03
updated: 2026-07-07
area: "[[Personal]]"
project: "[[AGENTS OS]]"
application:
entities:
  - "[[AGENTS OS]]"
  - "[[Graphify]]"
related:
  - "[[agent-constitution]]"
  - "[[graphify]]"
  - "[[LLM Wiki]]"
  - "[[agents-os-tagging-system]]"
aliases:
  - arquitectura de indexacion economia de tokens
  - token economy indexing architecture
  - indices graphify vs llm wiki ADR
  - capas de retrieval
confidence: verified
source_session:
load_policy: when_project_loaded
indexable: true
index_priority: high
tags:
  - area/personal
  - kind/decision
  - priority/high
  - project/agents-os
  - project/agentsos
  - scope/project
---
# Arquitectura de Indexación para Economía de Tokens

## Contexto

- El vault existe para **economía de tokens**: un agente debe entender lo necesario
  cargando en su contexto **solo el mínimo**, sin basura.
- Conviven varios "métodos de indexación": tags/frontmatter, `00-index.md` curado
  (LLM Wiki), grafo AST de Graphify, y la extracción semántica de Graphify (LLM).
- Sin reglas claras se cae en dos fallas: (a) basura entra al contexto (nodos-god
  de JSON, trash, prosa completa); (b) se paga LLM para redescubrir lo que la wiki
  ya cura. Verificado 2026-07-02/03: corpus contaminado (512 trash + 170 json) y
  el free tier de Gemini no alcanza para la semántica del vault.

## Decisión

Retrieval en **4 capas, cada una filtra antes de la siguiente**. Nunca saltar capas;
al modelo entra solo el mínimo.

```
Capa 0  TAGS/frontmatter   → filtro GRATIS: "¿qué conjunto?"         (grep/dataview, 0 tokens LLM)
Capa 1  00-index.md (wiki)  → catálogo curado: "¿qué página abro?"   (leer 1 archivo)
Capa 2  graph.json (AST)    → relaciones/paths/lint                  (lectura programática mínima)
Capa 3  cuerpo de la nota   → SOLO lo elegido, SOLO el body          (lectura quirúrgica)
```

Roles fijos de cada índice:

- **LLM Wiki = capa semántica + retrieval primario (fuente de verdad).** Las conexiones
  se escriben curadas como `[[links]]` al ingerir; el `00-index.md` es el catálogo.
- **Graphify (modo `update`, AST, sin LLM) = índice estructural derivado.** Para
  auditoría/lint del grafo completo, `path`, `affected` y navegación. NO es verdad,
  se regenera. Se mantiene limpio vía `.graphifyignore`.
- **Tags = capa 0, filtro gratis.** Viven en **frontmatter** como slugs del vocabulario
  de `90-system/convenciones.md`. NUNCA tags inline en el cuerpo para indexar (ruido de
  grafo + entran al contexto). Linteados por `agents-os-tagging-system`.
- **Graphify semántico (`extract --mode deep`) = PARQUEADO.** Solo para proyectos de
  **código** y solo vía API paga cuando se justifique. No se usa en el vault de markdown.

Regla dura anti-basura: cargar **solo el body** de una nota (sin frontmatter ni bloques
`tasks`), y aplicar techos blandos de tokens por tier en cada query (suficiencia-first,
no guillotina; ver [[context-router]]).

### grep vs graphify vs semántica (tres herramientas, tres preguntas)

No se solapan; elegir la barata que responde la pregunta antes de escalar:

| Herramienta | Pregunta que responde | Costo |
|---|---|---|
| **grep / búsqueda de texto** | *¿dónde está?* — encontrar una cadena/nota exacta | gratis |
| **graphify (AST)** | *¿con qué se relaciona?* — edges, `path`, `affected`, lint | gratis (sin LLM) |
| **semántica (LLM)** | *¿qué significa?* — similitud conceptual, síntesis | caro (API paga) |

Corolario clave: **grep encuentra, graphify relaciona, la semántica significa.** Curar
`[[links]]` e índices reduce la necesidad de semántica. Y para relaciones **del vault**, el
fork **`graphify-obsidian`** (vault-aware) ya convierte los `[[wikilinks]]` en edges
`references` (resuelto 2026-07-04; sin builder standalone) → la Capa 2 relacional funciona
también en el vault, no solo en código. El grafo relaciona por **links** (wikilinks → edges
`references`), **no por tags** (los tags son Capa 0, filtro de frontmatter).

### Relaciones graphifeables: links tipados (input del builder)

La Capa 2 del vault ya funciona: `graphify-obsidian` emite un edge `references` por cada
`[[wikilink]]`. Los links tipados (**implementados 2026-07-07** en el fork) tipan esas
relaciones: el verbo distingue el `relation` del edge. Contrato:

- **Verbos canónicos (única forma aceptada):** `consume`, `decora`, `depende de`, `expone`,
  `reemplaza a` (case-insensitive). El verbo → `relation` reemplazando espacios por `_`
  (`depende de [[X]]` → `depende_de`, `reemplaza a [[Y]]` → `reemplaza_a`). **Sin variantes
  bare** (`depende`/`reemplaza` solos NO se tipan): dos nombres para la misma relación
  fragmentarían el grafo. Sin verbo canónico → `references`.
- **Scoping obligatorio a `## Relaciones`:** el parser tipa **solo** dentro de esa sección
  del cuerpo (los sub-headings más profundos la mantienen abierta; un heading hermano/padre
  la cierra). Fuera de ella un verbo es prosa —incluida una **negación** "no depende de
  [[X]]"— y el link cae a `references`. Esto es lo que preserva el determinismo. No en
  frontmatter, **nunca inline como tags**. Una relación = una línea (`grep`/diff-eable).
- **`RELATIONS.md`/MOC por dominio — descartado como fuente:** mantener una edge-list a
  mano es doble fuente de verdad (drift). La relación se escribe **una vez** en `## Relaciones`;
  el edge-list/MOC, si se quiere, se **genera** con `graphify-obsidian`, no se cura a mano.
  (Consistente con "una fuente canónica por hecho".)
- **Query:** los edges tipados, como `references`, no están en las relaciones por defecto de
  `affected` → recorrerlos exige `--relation <tipo>` explícito (ej. `affected "<nota>.md"
  --relation depende_de`). Ver [[Economía de Tokens]] y `graphify.md`.

## ¿Graphify (solo índices) aporta o estorba?

**Aporta — NO estorba — siempre que:** (1) el corpus esté limpio (`.graphifyignore`),
y (2) se use para lo que es bueno: **lint/auditoría del grafo completo** (huérfanos,
god-nodes, links rotos), `affected`/`path` y descubrimiento cross-dominio — cosas que
el `grep` sobre `00-index.md` no hace por sí solo.

**Estorba solo si:** se ensucia el corpus, o se lo usa como capa de retrieval/semántica
de markdown (ahí ganan los tags + el índice curado). A la escala actual su valor es
**acotado pero real**; el motor de ahorro de tokens son las capas 0-1, Graphify es el
auditor estructural de apoyo.

## Rationale

- Cada capa más barata filtra antes de la más cara → el contexto del modelo recibe el mínimo.
- Los tags en frontmatter permiten retrieval sin leer cuerpos (0 tokens LLM).
- La wiki curada da semántica confiable sin costo de extracción ni alucinaciones.
- Graphify AST es gratis (sin LLM) y cachea por hash: correrlo seguido cuesta casi nada.
- Markdown como fuente de verdad; Graphify como índice derivado y desechable.

## Consecuencias

- Se construye un **wrapper/capa delgada sobre `graph.json` + `00-index.md`** que emite
  el paquete mínimo de contexto con **techo blando por tier** (suficiencia-first, no
  guillotina; ver [[context-router]]). graphify queda intacto (no se parchea
  `site-packages`; fork editable solo si hiciera falta).
- El protocolo de 4 capas se documenta en la skill de retrieval y en el contrato de
  Graphify (`80-agents/skills/_shared/graphify-contract.md`).
- El **cómo cargar** (decidir qué capa/orden/presupuesto por tarea) se formaliza como el
  concepto [[context-router]], implementado por la skill de retrieval. Es la pieza de
  evangelización para el equipo.
- `00-RESOURCE-WIKI.md` y `graphify.md` referencian este ADR para el "aporta/estorba".
- La medición del ahorro (`graphify benchmark` + feedback/kaizen) es deseable pero
  opcional; ver idea en `30-resources/ideas/`.

## Alternativas descartadas

- **Solo Graphify (con semántica) sin wiki:** semántica LLM de markdown ruidosa/cara y
  free tier insuficiente; alucinaciones no confiables.
- **Solo wiki sin Graphify:** se pierde el lint/traversal del grafo completo y el
  `affected`/`path` programático.
- **Sin tags / tags inline en el cuerpo:** rompe el filtro gratis de capa 0 y ensucia
  el grafo con nodos-god.
- **Cargar notas completas (con frontmatter/tasks):** mete basura evitable al contexto.

<!-- ===== END CANONICAL FILE: 80-agents/memory/public/decision/agents-os/token-economy-indexing-architecture.md ===== -->

<!-- ===== BEGIN CANONICAL FILE: 80-agents/skills/agents-os-bootstrap/SKILL.md ===== -->

---
type: skill
schema_version: 1
name: agents-os-bootstrap
scope: global
created: 2026-07-04
updated: 2026-09-03
description: Mandatory AGENTS OS startup skill. Run once at cold start when a new session begins or the user explicitly asks to load AGENTS OS. Its loaded contract governs warm turns and entity swaps without rereading the skill or base stack. Loads the minimum operating stack and routes entity-specific context lazily.
entities:
  - "[[AGENTS OS]]"
  - "[[agents-os]]"
load_policy: always
indexable: true
index_priority: critical
tags:
  - kind/skill
  - scope/global
  - agent/alwaysload
  - action/bootstrap
  - tech/agents-os
---

# agents-os-bootstrap — AGENTS OS Startup

## Purpose

Single canonical startup for AGENTS OS. Detects session mode (cold / warm /
swap-entity), loads only the relevant stack, resolves the active entity, and
routes to one specialized skill when needed. Nothing else should redefine
startup.

## Canonical Authority

`AGENTS.md` invokes this skill; this file owns startup. `agents-os.md` is only
the conceptual map, the constitution contains invariants, specialized skills
contain lazy procedures, and project/journal notes contain state/history.

## Session Modes

Pick exactly one per turn:

- **Cold start** — first turn of a conversation, or no entity loaded yet.
  Load: constitution + global profile + ONE compact global internal note +
  active entity context via Context Router.
- **Warm turn, same entity** — continuation of an ongoing task on the same
  entity. Reuse what is already in context. Fetch only the delta needed.
  Never re-read constitution/profile/bootstrap.
- **Entity swap** — same conversation switches to a different entity/topic.
  Keep constitution + global profile; replace entity pack; skip global
  internal reload if already loaded this session.

Invalidation signals (re-read the affected source only, not the whole stack):
the user names a new entity, the intent clearly shifts, or a base source
changed on disk. Do NOT re-run the full ritual on every message.

## Procedure

### Cold start

1. Load always-load public invariants:
   - `80-agents/agents-os/agent-constitution.md`
   - `80-agents/memory/public/user-preference/rjara-agent-profile.md`
2. Load exactly ONE global internal note:
   `80-agents/memory/internal/agent-memory/global/agents-os-operating-continuity.md`.
   Do not scan `memory/internal/` for `always` notes; the contract below
   forbids any other `always` outside this single global note.
3. Read `agents-os.md` only if the task needs the conceptual map; do not add it
   to the base stack by ritual.
4. Identify the active entity from the user's request. If not explicit,
   infer candidates with a focused search and declare the assumed entity.
   Resolve aliases/slugs to the canonical Obsidian title.
5. If the request needs vault state or domain context, route to `agents-os-context-retrieval` for the active entity (cheapest layer first; stop when sufficient). For casual or general requests that do not depend on a vault entity, skip entity retrieval.
6. Open source Markdown only for notes that affect a persistent decision,
   edit, or answer that must be verified.
7. Select at most ONE specialized skill (lazy-load) only if the task needs it.
8. Skip the orientation note unless retrieval was degraded. If degraded,
   emit the minimal `Entity / Goal / Skills / Open questions` note and flag
   the gap.

### Warm turn

1. Reuse the stack already loaded.
2. Fetch only the delta required for the new turn.
3. Only re-read a source if it changed on disk or the entity/intent shifted.
4. Do not invoke or reread bootstrap merely because the user sent another message.

### Entity swap

1. Keep the invariants and global internal note from cold start.
2. Resolve the new entity and route to `agents-os-context-retrieval` for it.
3. Drop the previous entity pack from active reasoning.

## Lazy Skill Routing

Use `80-agents/skills/INDEX.md` as the registry. Match the task to one primary
skill and load that `SKILL.md`; load a dependency only if its procedure
requires it. Common direct routes: close → `agents-os-session-close`, repair
AGENTS OS → `agents-os-doctor`, project execution →
`agents-os-agent-project-workflow`, entity merge →
`agents-os-entity-lifecycle`, reindex → `agents-os-graphify-maintenance`.

Do not load Nexus, MELI, or external project skills unless the request
explicitly asks for them.

## Hard Rules

- This skill is the only startup procedure. Do not duplicate it in
  `agents-os.md`, `AGENTS.md`, adapters, or project notes.
- Invariants load once per session (cold start). Warm turns reuse.
- Only ONE global internal note may use `load_policy: always`, and it may contain only compact behaviors or failure lessons transferable across domains. Domain state, releases, hashes, task progress and project-specific next steps must use `when_project_loaded`, `when_application_loaded`, `when_error_matches` or `manual`.
- Internal continuity uses one active checkpoint per `continuity_key`. Update it in place after consuming it; if replacement is required, retire the prior checkpoint to `superseded` plus `manual` in the same change. Never load `superseded` or `archived` continuity during normal startup or entity retrieval.
- Prefer Graphify / focused search before opening broad folders.
- Use canonical Obsidian titles for entity links; aliases/slugs are routing.
- Resolve vault paths from `VAULT_ROOT`; never persist a machine-specific
  absolute vault path.
- Do not create memory notes during bootstrap.
- Do not load the AGENTS OS development project unless the task is
  maintaining the system itself.
- Sufficiency-first context: the budget is a soft ceiling that escalates on
  miss, never a fixed cut. See `../_shared/graphify-contract.md`.
- Skip the orientation note unless retrieval was degraded.

## Token Targets (soft)

Cold base 3–6k tokens; warm delta <1k; entity swap 1–3k. Never cut relevant
context to satisfy a number; investigate duplicate reads or broad scans.

## Output

On cold start, optionally emit a one-line orientation:

```
Entity: [[<canonical>]] · Goal: <one phrase> · Skills selected: <list or none>
```

On warm turn or entity swap, no output unless something is wrong.

<!-- ===== END CANONICAL FILE: 80-agents/skills/agents-os-bootstrap/SKILL.md ===== -->

<!-- ===== BEGIN CANONICAL FILE: 80-agents/skills/agents-os-context-retrieval/SKILL.md ===== -->

---
type: skill
schema_version: 1
name: agents-os-context-retrieval
scope: global
created: 2026-07-04
updated: 2026-09-03
description: Retrieve focused context for the Agent Memory System using Graphify or an equivalent index. Use when an agent needs project/application/entity context, learnings, ADRs, known errors, runbooks, integrations, or related notes before working, while keeping context/token usage low.
entities:
  - "[[AGENTS OS]]"
  - "[[agents-os]]"
  - "[[context-router]]"
load_policy: when_entity_loaded
indexable: true
index_priority: critical
tags:
  - kind/skill
  - scope/global
  - agent/alwaysload
  - action/retrieval
  - tech/agents-os
---

# Agent Memory System Context Retrieval

## Purpose

Load the smallest useful context set. Markdown is canonical; Graphify is a derived index.

## Minimal Read

Read `../_shared/graphify-contract.md` only for syntax, budgets or fallback. Read [[token-economy-indexing-architecture]] and [[context-router]] only to justify a design decision.

## Inputs

- Entity or candidate entity.
- Topic or task.
- Available retrieval interface: `graphify-obsidian`, shell, IDE search, MCP/tool, or manual graph output.

## The four layers (route cheapest → most expensive)

Each layer reduces candidates before the next. **Start at the cheapest layer relevant to the intent** — this is not a strict waterfall that always begins at Layer 0. Pick an entry layer per intent, then climb only if insufficient. Never load a body without a prior selection.

```
Layer 0  metadata/facets    → exact file-node selection         (`filter`, 0 LLM tokens)
Layer 1  00-index.md        → curated domain catalog            (read one selected index)
Layer 2  graph relations    → typed edges + wikilink references (`path`/`affected`/`query`)
Layer 3  note body          → only chosen Markdown sources      (body-only, surgical read)
```

## Procedure

1. **Resolve the entity** to its canonical Obsidian file node through an exact file title (`<canonical>.md`) or alias filter before lexical fallback. Treat slug, repo and path as fallback routing signals; once resolved, retain the canonical Obsidian title without the `.md` suffix for wikilinks and user-facing output.
2. **Classify the intent** — fact · relation/impact · domain synthesis · code · procedure — and pick the **entry layer**, then climb cheap→expensive only as needed:

   | Intent | Entry layer | Climb if |
   |---|---|---|
   | Fact about a known entity | exact title/alias plus metadata facets | projected metadata lacks the fact |
   | Relation / impact | resolve file node, then typed graph edges and `references` | relation is absent, ambiguous or stale |
   | Domain synthesis | type/tag/routing facets → domain `00-index.md` → filtered lexical query | catalog and candidates are insufficient |
   | Code question | graphify **code** graph (`explain`/`affected`) → specific symbols | symbol missing |
   | Procedure | `type=runbook` or `type=skill` plus entity/routing filters | exact candidates do not cover the operation |
   | Unresolvable entity | title/alias filter → focused `rg`/keyword search → declare assumed entity | still ambiguous |

3. Call the needed `graphify-obsidian` query directly. The wrapper checks freshness
   and rebuilds its machine-local index automatically; do not prepend a manual update.
4. **Layer 0 selection:** use `graphify-obsidian filter` for exact `type`, `tag`, `scope`, `status`, routing, file title or alias matches. `--title` targets the file-node label and therefore includes `.md`; `--alias` uses the frontmatter value without a suffix. Combine repeated filters as an intersection. Use `query --filter key=value` only after facets have defined the candidate set; lexical terms rank inside that set rather than searching the whole corpus.
5. **Climb from the entry layer cheap→expensive; stop when sufficient.** Bootstrap already loaded the base invariants on cold start: do not reload them here. Within entity context prefer the canonical entity file, then `memory_state: active` scoped continuity with a matching `continuity_key`, active decisions/errors and relevant runbooks. Ignore `superseded` and `archived` memory unless the user asks for history; treat lifecycle-less legacy memory as candidates, never as a set to bulk-load, and migrate it when touched.
6. **Layer 2 relations:** traverse allowlisted frontmatter edges (`in_area`, `child_of`, `in_project`, `for_application`, `about`, `related_to`, `supersedes`) before generic body links when the question names that relation. Vault `[[wikilinks]]` remain `references` edges. Query backlinks with `graphify-obsidian affected "<note>.md" --relation references`; the `.md` suffix and explicit relation are required for generic backlinks. See `../_shared/graphify-contract.md`.
7. **Layer 3 body-only:** open only selected source notes and load their body without frontmatter or `tasks` blocks. A persisted decision or edit still requires verification against source Markdown because Graphify is derived.
8. Keep the context-pack inventory internal. Expose it only on degradation, ambiguity that affects the answer, or explicit audit. If a layer misses, escalate one layer and continue with the safest narrow assumption.

## Noisy Query Handling

If results anchor on templates, plugins, generated files or generic headings,
reject them. Retry with `canonical entity + memory type + concrete symptom`;
then use exact source search if still noisy. Record degradation, not “missing
knowledge”.

## Context Budget — sufficiency-first, soft ceilings

Do **not** cut context at a fixed number; that was a design error. Load cheap→expensive and **stop when the context is sufficient**. The budget is a per-tier **soft ceiling** and a smell-test, never a guillotine — the ceilings grow with the depth the intent needs:

```
fact       < relation < synthesis
(low)        (medium)   (medium-high)
```

Escalate past a tier's ceiling only after a miss, and record why.

Priority within an entity load: entity note or `explain`; critical/high scoped
memories; matching known errors; runbooks only for an operation. Prefer a
verified source over several graph neighbors.

When context is tight, prefer one verified source note over several graph neighbors.

## Fallback

Without shell, request `update`, `filter`, `explain`, `query`, `path` or `affected` from the host bridge. If exact metadata filtering is unavailable, emulate it over `graph.json`; if Graphify is unavailable or stale, use focused Markdown search, open only top candidates and report degraded status plus confidence.

## Output — the context pack

Track internally: intent, canonical entity, route/layers, selected sources,
approximate tokens, confidence and gaps. Show it only on degradation or audit.

## Validation

Run `python3 80-agents/skills/agents-os-context-retrieval/scripts/context_router_e2e.py --json` from `VAULT_ROOT`. The no-API matrix exercises project, skill, prompt, known_error, resource, application and typed project relations through two independent surfaces: the Graphify CLI and focused Markdown fallback. It fails on missing or extra candidates and reports miss rate, precision proxy, p95 latency and selected body count against the recorded Phase 2 baseline.

## Hard Rules

- Do not use abstract queries like "give me important context".
- Do not treat template nodes as evidence of live project state.
- Do not treat Graphify output as canonical without opening source notes when the answer affects persisted knowledge.
- Do not write, copy or sync Graphify output inside the vault; resolve local state through `graphify-obsidian cache-path`.
- Do not load raw sessions by default.
- Do not create or trust duplicate entity targets caused only by case, accent,
  singular/plural, or alias differences.
- Do not load a note body without a prior selection through facets, a curated index or graph relations. Body is the most expensive layer; reach it last, only for the chosen note.
- Do not cut context at a fixed token number; stop by sufficiency, not by guillotine.
- Tags are exact facets, never graph edges. For vault relations use typed frontmatter edges when semantics are explicit and `references` for generic wikilinks.

<!-- ===== END CANONICAL FILE: 80-agents/skills/agents-os-context-retrieval/SKILL.md ===== -->

<!-- ===== BEGIN CANONICAL FILE: 80-agents/skills/agents-os-session-close/SKILL.md ===== -->

---
type: skill
schema_version: 1
name: agents-os-session-close
scope: global
created: 2026-07-05
updated: 2026-08-11
description: Close an AGENTS OS session into reusable memory artifacts by delta. Use when the user says "cierra sesión", asks to persist session learnings, or invokes this skill by name. Decides what (if anything) to persist based on the session delta; default report is one or two lines.
entities:
  - "[[AGENTS OS]]"
  - "[[agents-os]]"
load_policy: manual
indexable: true
index_priority: high
tags:
  - kind/skill
  - action/close
  - tech/agents-os
  - scope/global
---

# Agent Memory System Session Close

## Purpose

Close a session by **delta**, not by ritual. Decide what (if anything) needs
to persist, persist only that, and report to the user in one or two lines
unless they ask for detail.

Two surfaces are intentionally separate:

- **Persistence** — what AGENTS OS needs to keep.
- **Report** — what the user needs to see.

## Minimal Read

Canonical create: use `materialize_schema_note.py` per `note-types.md`; never hand-copy frontmatter.

Read only when needed:

- `../_shared/metadata-schema.md` for frontmatter.
- `../_shared/note-types.md` for artifact boundaries.

## Inputs

- Current session context.
- Main entity / project / application.
- External session identifier (when exposed by the surface). Belongs only in
  `source_session`, never in the filename.
- Canonical agent surface, exact host/user-reported model and attributable code-work segments, when code was generated or evaluated.

## Procedure

## Trigger Guard

Run only when one of these holds:

- The user explicitly asks to close the session ("cierra sesión", "cierra
  AGENTS OS", "cierra con detalle").
- The user asks to persist the session as closeout artifacts.
- The user invokes this skill by name.

Finishing a task, reaching a checkpoint, or noticing reusable knowledge is
NOT a trigger by itself.

## Delta Classifier

Select every row whose trigger is evidenced; most sessions match one. Act only
on those rows.

| Session delta | Action |
|---|---|
| No new knowledge or state | No artifacts. Report `Continuidad lista. Próximo paso: X.` |
| Operational continuity only | Update project/control note OR internal memory checkpoint, not both. No L0/L1. |
| Reusable knowledge (rule/decision/error/runbook/entity fact) | L3 + `change_log` + targeted Graphify reindex |
| Transcript available or explicitly requested | L0; L1 only if it adds navigation beyond the project note |
| Real friction / degradation / gap detected | Brief feedback note (event-driven, see below) |
| Material code-generation/evaluation segment | Ensure one `agent_run` per attributable surface×model via `agents-os-agent-run-register`; this is independent from feedback and creates no L0/L1. |
| Explicit audit request | Show full inventory (L0 + L1 + L3 + feedback + logs + Graphify status) |

## Default Report

One or two lines. Do not enumerate artifacts created, updated, or skipped
unless the user asks for detail or an error/conflict needs a decision.

```text
Sesión cerrada. Continuidad lista. Próximo paso: <X>.
```

Nothing else by default. No tables of artifacts. No `L0 / L1 / L3 / feedback /
logs / Graphify / next tasks` inventory — that lives in the **detailed mode**.

## Detailed Mode

Triggered by `cierre con detalle`, an explicit audit request, or when a
conflict/error needs a human decision. Output the full inventory:

```text
Raw session:
Session summary:
Session feedback:
Learnings:
ADRs:
Known errors:
Runbooks:
Entity updates:
Conflicts:
Journal logs:
Graphify action:
Next tasks:
```

## Closeout Naming

When L0/L1 are created, use:

```text
80-agents/journal/sessions/raw/YYYY-MM-DD[-HHMM]-<human-topic>-raw.md
80-agents/journal/sessions/YYYY-MM-DD[-HHMM]-<human-topic>-summary.md
```

Rules:

- `<human-topic>` is lowercase kebab-case derived from the project, app, or
  session objective.
- `HHMM` only on same-day title collisions.
- External IDs, UUIDs, hashes go in `source_session` only.
- Never use a UUID/hash as the filename, prefix, H1, or human topic.
- L1 summaries live directly under `80-agents/journal/sessions/`; do not
  create sibling `summary/`, `summaries/`, or `system-1/` directories.

## Tactical Mode (subsumed by Delta Classifier)

The old "tactical mode" was a special case of the delta classifier. It
applies when **all** hold:

- The work was operational/tactical (code-review, debug, triage, lookup).
- No reusable rule, decision, known-error, runbook, or Sistema 2 fact emerged.
- The session's value is continuity, not canon.

In that case: keep the floor, skip the expensive tail. Optionally update
internal memory if there is real continuity delta (mandamiento 16 is
delta-based now, not mandatory per session). Skip feedback unless friction
was real. Skip L1/L3/entity/reindex unless real knowledge emerged.

When evidence is insufficient to classify knowledge as reusable, do not
inflate the close. Preserve only operational continuity and leave the
classification as an explicit follow-up if it can affect a future decision.

## Close Artifact Budget (soft ceiling + link, don't describe)

Ephemeral close scaffolding (L0 + L1 + feedback combined) targets a **soft
ceiling of ~1–1.5k tokens**. Smell-test, not guillotine. Hit it by **linking,
not truncating**:

- Reference entities, logs, and notes with `[[wikilinks]]`. The vault-aware
  graph (`graphify-obsidian`, Layer 2) resolves the link; the context is one
  hop away without padding the summary.
- Prefer link + one line over a paragraph.

**L3 memory is exempt.** Learnings, decisions, known-errors, runbooks are
reusable knowledge — write them (compact per their own rule) even if they
push past the ceiling. Trimming L3 to fit a number repeats the retrieval-cap
design error.

## Output

- Default: the 1-2 line report above.
- Detailed: the inventory block above.

## Hard Rules

- Do not run a full AGENTS OS close automatically at task completion. Wait
  for an explicit user closeout request. If continuity is needed without a
  closeout request, update the relevant project/control note or internal
  memory compactly instead of creating L0/L1/feedback.
- Persistence ≠ Report. The user does not need to see the inventory unless
  they asked for detail or a decision is needed.
- Decide artifacts by the delta classifier. Do not create more than the
  delta justifies.
- Create L0 only when transcript content is available or the user explicitly
  asks for a placeholder. Never create an empty L0 by ritual.
- Never use UUID/hash/external ID as filename, prefix, H1, or human topic.
- Never overwrite a canonical entity fact without a journal log.
- Feedback is event-driven (next section).

## Feedback (event-driven)

Create a feedback note ONLY when one of these holds:

- Real friction was encountered (tool failure, missing support, slow path).
- Retrieval was degraded and a workaround was needed.
- A gap in Sistema 1 was detected that the system does not solve.
- Periodic sampling (e.g. the hygiene cycle asks for one this week).

Do NOT create feedback just because the closeout ran. A clean session with
no friction → no feedback note.

When feedback is warranted:

- One general note under `80-agents/journal/feedback/system-1/` using
  `YYYY-MM-DD-<entity-or-topic>-session-feedback.md`.
- Graphify-specific feedback is captured during `agents-os-hygiene-cycle`
  aggregation, NOT as a second automatic note at every close. Only create a
  dedicated Graphify feedback note if Graphify was used AND something
  notable happened (degradation, novel query pattern, new pitfall).
- Keep answers short: 1-3 bullets per section. One Pain Pattern Candidate
  at most.

## Graphify Reindex

Recommend reindex via `agents-os-graphify-maintenance` only when:

- L3 memory or entity updates were created this session.
- Source files changed on disk in ways that affect the index.

Tactical/no-artifact closes do not require reindex.

## Agent Run Registration

Before final reporting, invoke `agents-os-agent-run-register` for every material coding/debug/review/testing segment from the session that is not already recorded. A model switch or cross-surface handoff creates separate runs; never infer an unreported model. Runs are journal evidence, not session feedback, and do not require Graphify reindex by themselves.

<!-- ===== END CANONICAL FILE: 80-agents/skills/agents-os-session-close/SKILL.md ===== -->
