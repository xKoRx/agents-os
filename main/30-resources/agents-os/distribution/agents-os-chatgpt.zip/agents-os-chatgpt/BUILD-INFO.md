# Build information

- Generated: 2026-09-03 20:54:59 -04
- Files: 194
- Source bytes: 952800
- Builder: `30-resources/agents-os/chatgpt-pack/build-pack.sh`
- Selection: `30-resources/agents-os/chatgpt-pack/sources.list`
- Validation: source/copy SHA-256 equality for every file
